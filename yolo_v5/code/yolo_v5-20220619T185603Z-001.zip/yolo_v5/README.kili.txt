Exported Labels from KILI
=========================

- Project name: workpiece_detection
- Project identifier: cl4cylr376yuu0lo806fm753j
- Project description: FSM
- Export date: 20220614-073435
- Exported format: yolo_v5
- Exported labels: LATEST
